import { getRelevantPart } from 'C:/Users/shrey/Project_113/code/src/services/aiService'; 
import { Part } from 'C:/Users/shrey/Project_113/code/src/services/types';

describe('getRelevantPart', () => {
  it('should return the correct part ID based on issue and parts', async () => {
    const issue = {
      title: 'Sample Issue',
      description: 'Description of the issue',
      tags: ['bug', 'urgent'],
    };

    const parts: Part[] = [
      {
        id: '1',
        name: 'Part A',
        attributes: {},
        type: 'Type A' 
      },
      {
        id: '2',
        name: 'Part B',
        attributes: {},
        type: 'Type B' 
      },
    ];

    const result = await getRelevantPart(issue, parts);
    expect(result).toBe('1'); 
  });
});
