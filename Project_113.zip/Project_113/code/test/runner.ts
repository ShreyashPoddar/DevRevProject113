/*
 * Copyright (c) 2024 DevRev Inc. All rights reserved.

Disclaimer:
The code provided herein is intended solely for testing purposes.
Under no circumstances should it be utilized in a production environment. Use of
this code in live systems, production environments, or any situation where
reliability and stability are critical is strongly discouraged. The code is
provided as-is, without any warranties or guarantees of any kind, and the user
assumes all risks associated with its use. It is the responsibility of the user 
to ensure that proper testing and validation procedures are carried out before 
deploying any code into production environments.
*/

import bodyParser from 'body-parser';
import express, { Express, Request, Response } from 'express';
import { callFunction, FunctionFactoryType } from '../src/function-factory'; 
import { ExecutionResult, FunctionError, RuntimeError, RuntimeErrorType, SnapInsSystemUpdateRequest, SnapInsSystemUpdateRequestStatus, SnapInsSystemUpdateResponse } from './types';
import { HTTPClient, HttpRequest } from './http_client';

const app: Express = express();
app.use(bodyParser.json(), bodyParser.urlencoded({ extended: false }));

export const startServer = (port: number) => {
  app.listen(port, () => {
    console.log(`[server]: Server is running at http://localhost:${port}`);
  });
};

app.post('/handle/async', async (req: Request, resp: Response) => {
  const events = req.body;
  if (!events) {
    resp.status(400).send('Invalid request format: body is undefined');
    return;
  }

  await handleEvent(events, true, resp);
});

app.post('/handle/sync', async (req: Request, resp: Response) => {
  if (!req.body) {
    resp.status(400).send('Invalid request format: body is undefined');
    return;
  }

  const events = [req.body]; 
  await handleEvent(events, false, resp);
});

async function handleEvent(events: any[], isAsync: boolean, resp: Response){
  let error: RuntimeError | undefined;
  const results: ExecutionResult[] = [];

  if (!Array.isArray(events)) {
    error = { err_type: RuntimeErrorType.InvalidRequest, err_msg: 'Body is not an array' };
    resp.status(400).send(error.err_msg);
    return;
  }

  if (!isAsync && events.length > 1) {
    error = { err_type: RuntimeErrorType.InvalidRequest, err_msg: 'Multiple events for synchronous request' };
    resp.status(400).send(error.err_msg);
    return;
  }

  if (isAsync) {
    resp.status(200).send(); 
  }

  for (const event of events) {
    let result;
    const functionName: FunctionFactoryType = event.execution_metadata.function_name as FunctionFactoryType;

    if (!functionName) {
      error = { err_type: RuntimeErrorType.FunctionNameNotProvided, err_msg: 'Function name not provided' };
      console.error(error.err_msg);
    } else {
      try {
        result = await callFunction(functionName, event); 
      } catch (e) {
        let error: FunctionError; 
        let errorMessage: string;
    
        if (e instanceof Error) {
            errorMessage = e.message; 
        } else {
            errorMessage = 'Unknown error occurred';
        }
    
        error = { error: errorMessage }; 
        console.error(`Error running function ${functionName}:`, errorMessage);
    }
    results.push({ function_result: result, error });
  }

  if (!isAsync) {
    resp.status(200).send(results[0]); 
  }
}
}

async function postRun(event: any, error: RuntimeError | undefined, result: any) {
  console.debug('Function execution complete');
  if (isActivateHook(event)) {
    handleActivateHookResult(event, error, result);
  } else if (isDeactivateHook(event)) {
    handleDeactivateHookResult(event, error, result);
  }
}

function isActivateHook(event: any): boolean {
  return event.execution_metadata.event_type === 'hook:snap_in_activate';
}

function isDeactivateHook(event: any): boolean {
  return event.execution_metadata.event_type === 'hook:snap_in_deactivate';
}

function handleActivateHookResult(event: any, handlerError: RuntimeError | undefined, result: any) {
  let update_req: SnapInsSystemUpdateRequest = {
    id: event.context.snap_in_id,
    status: SnapInsSystemUpdateRequestStatus.Active,
    inputs_values: result?.inputs_values || {},
  };

  if (handlerError || result?.status === 'error') {
    update_req.status = SnapInsSystemUpdateRequestStatus.Error;
  }

  return updateSnapInState(event, update_req);
}

function handleDeactivateHookResult(event: any, handlerError: RuntimeError | undefined, result: any) {
  let update_req: SnapInsSystemUpdateRequest = {
    id: event.context.snap_in_id,
    status: SnapInsSystemUpdateRequestStatus.Inactive,
    inputs_values: result?.inputs_values || {},
  };

  if (handlerError || result?.status === 'error') {
    update_req.status = SnapInsSystemUpdateRequestStatus.Error;
  }

  return updateSnapInState(event, update_req);
}

async function updateSnapInState(event: any, update_req: SnapInsSystemUpdateRequest){
  const { secrets } = event.context;
  const client = new HTTPClient({
    endpoint: event.execution_metadata.devrev_endpoint,
    token: secrets?.service_account_token,
  });

  const request: HttpRequest = {
    path: '/internal/snap-ins.system-update',
    body: update_req,
  };

  try {
    await client.post<SnapInsSystemUpdateResponse>(request);
  } catch (e) {
    console.error('Error updating snap-in state:', e);
  }
}
