"use strict";
/*
 * Copyright (c) 2024 DevRev Inc. All rights reserved.

Disclaimer:
The code provided herein is intended solely for testing purposes.
Under no circumstances should it be utilized in a production environment. Use of
this code in live systems, production environments, or any situation where
reliability and stability are critical is strongly discouraged. The code is
provided as-is, without any warranties or guarantees of any kind, and the user
assumes all risks associated with its use. It is the responsibility of the user
to ensure that proper testing and validation procedures are carried out before
deploying any code into production environments.
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startServer = void 0;
const body_parser_1 = __importDefault(require("body-parser"));
const express_1 = __importDefault(require("express"));
const function_factory_1 = require("../src/function-factory"); // Ensure callFunction is correctly imported
const types_1 = require("./types");
const http_client_1 = require("./http_client");
const app = (0, express_1.default)();
app.use(body_parser_1.default.json(), body_parser_1.default.urlencoded({ extended: false }));
const startServer = (port) => {
    app.listen(port, () => {
        console.log(`[server]: Server is running at http://localhost:${port}`);
    });
};
exports.startServer = startServer;
// handle async requests
app.post('/handle/async', async (req, resp) => {
    const events = req.body;
    if (!events) {
        resp.status(400).send('Invalid request format: body is undefined');
        return;
    }
    await handleEvent(events, true, resp);
});
// handle sync requests
app.post('/handle/sync', async (req, resp) => {
    if (!req.body) {
        resp.status(400).send('Invalid request format: body is undefined');
        return;
    }
    const events = [req.body]; // wrap sync request in array
    await handleEvent(events, false, resp);
});
async function handleEvent(events, isAsync, resp) {
    let error;
    const results = [];
    if (!Array.isArray(events)) {
        error = { err_type: types_1.RuntimeErrorType.InvalidRequest, err_msg: 'Body is not an array' };
        resp.status(400).send(error.err_msg);
        return;
    }
    if (!isAsync && events.length > 1) {
        error = { err_type: types_1.RuntimeErrorType.InvalidRequest, err_msg: 'Multiple events for synchronous request' };
        resp.status(400).send(error.err_msg);
        return;
    }
    if (isAsync) {
        resp.status(200).send(); // send a response immediately for async
    }
    for (const event of events) {
        let result;
        const functionName = event.execution_metadata.function_name;
        if (!functionName) {
            error = { err_type: types_1.RuntimeErrorType.FunctionNameNotProvided, err_msg: 'Function name not provided' };
            console.error(error.err_msg);
        }
        else {
            try {
                result = await (0, function_factory_1.callFunction)(functionName, event); // Use callFunction instead of functionFactory
            }
            catch (e) {
                let error; // Use 'let' to allow reassignment
                let errorMessage;
                if (e instanceof Error) {
                    errorMessage = e.message; // Access the message property of the Error object
                }
                else {
                    errorMessage = 'Unknown error occurred'; // Handle unknown error types
                }
                error = { error: errorMessage }; // Create the error object without 'message'
                console.error(`Error running function ${functionName}:`, errorMessage);
            }
            results.push({ function_result: result, error });
        }
        if (!isAsync) {
            resp.status(200).send(results[0]); // send only the first result for synchronous requests
        }
    }
}
// post-processing based on function execution
async function postRun(event, error, result) {
    console.debug('Function execution complete');
    if (isActivateHook(event)) {
        handleActivateHookResult(event, error, result);
    }
    else if (isDeactivateHook(event)) {
        handleDeactivateHookResult(event, error, result);
    }
}
function isActivateHook(event) {
    return event.execution_metadata.event_type === 'hook:snap_in_activate';
}
function isDeactivateHook(event) {
    return event.execution_metadata.event_type === 'hook:snap_in_deactivate';
}
function handleActivateHookResult(event, handlerError, result) {
    let update_req = {
        id: event.context.snap_in_id,
        status: types_1.SnapInsSystemUpdateRequestStatus.Active,
        inputs_values: result?.inputs_values || {},
    };
    if (handlerError || result?.status === 'error') {
        update_req.status = types_1.SnapInsSystemUpdateRequestStatus.Error;
    }
    return updateSnapInState(event, update_req);
}
function handleDeactivateHookResult(event, handlerError, result) {
    let update_req = {
        id: event.context.snap_in_id,
        status: types_1.SnapInsSystemUpdateRequestStatus.Inactive,
        inputs_values: result?.inputs_values || {},
    };
    if (handlerError || result?.status === 'error') {
        update_req.status = types_1.SnapInsSystemUpdateRequestStatus.Error;
    }
    return updateSnapInState(event, update_req);
}
async function updateSnapInState(event, update_req) {
    const { secrets } = event.context;
    const client = new http_client_1.HTTPClient({
        endpoint: event.execution_metadata.devrev_endpoint,
        token: secrets?.service_account_token,
    });
    const request = {
        path: '/internal/snap-ins.system-update',
        body: update_req,
    };
    try {
        await client.post(request);
    }
    catch (e) {
        console.error('Error updating snap-in state:', e);
    }
}
