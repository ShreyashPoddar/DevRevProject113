"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aiService_1 = require("C:/Users/shrey/Project_113/code/src/services/aiService");
describe('AI Service Tests', () => {
    it('should return the correct part ID based on the issue', async () => {
        const issue = {
            title: 'Sample Issue',
            description: 'Description of the issue',
            tags: ['bug', 'urgent'],
        };
        const parts = [
            { id: '1', name: 'Part A', attributes: {} },
            { id: '2', name: 'Part B', attributes: {} },
        ];
        const result = await (0, aiService_1.getRelevantPart)(issue, parts);
        expect(result).toBeDefined();
    });
});
