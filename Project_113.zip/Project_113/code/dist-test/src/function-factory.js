"use strict";
// src/function-factory.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.callFunction = exports.functionB = exports.functionA = void 0;
// Example function implementations
const functionA = async (data) => {
    console.log('Function A executed with data:', data);
    // Add function A logic here
};
exports.functionA = functionA;
const functionB = async (data) => {
    console.log('Function B executed with data:', data);
    // Add function B logic here
};
exports.functionB = functionB;
// Function to call the appropriate function based on the function name
const callFunction = async (functionName, data) => {
    switch (functionName) {
        case 'functionA':
            return await (0, exports.functionA)(data);
        case 'functionB':
            return await (0, exports.functionB)(data);
        default:
            throw new Error(`Function ${functionName} is not defined`);
    }
};
exports.callFunction = callFunction;
