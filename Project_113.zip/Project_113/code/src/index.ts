// src/index.ts

import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { getRelevantPart } from './services/aiService';
import { Part } from './services/types';


export const processIssues = async (issue: { title: string; description: string; tags: string[] }, parts: Part[]): Promise<string | null> => {
  return await getRelevantPart(issue, parts);
};

(async () => {
  const argv = await yargs(hideBin(process.argv)).options({
    fixturePath: {
      required: true,
      type: 'string',
    },
    functionName: {
      required: true,
      type: 'string',
    },
  }).argv;

  if (!argv.fixturePath || !argv.functionName) {
    console.error('Please make sure you have passed fixturePath & functionName');
    return;
  }

  const issue = {
    title: 'Sample Issue',
    description: 'Description of the issue',
    tags: ['bug', 'urgent'],
  };

  const parts: Part[] = [
    {
      id: '1',
      name: 'Part A',
      attributes: {},
      type: 'Type A' 
    },
    {
      id: '2',
      name: 'Part B',
      attributes: {},
      type: 'Type B' 
    },
  ];

  const relevantPartId = await processIssues(issue, parts);
  console.log(`Relevant Part ID: ${relevantPartId}`);
})();
