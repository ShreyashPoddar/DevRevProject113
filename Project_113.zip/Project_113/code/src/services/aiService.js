"use strict";
// src/services/aiService.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRelevantPart = void 0;
const axios_1 = __importDefault(require("axios"));
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const getRelevantPart = (issue, parts) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const prompt = `
    Given the following issue details, suggest the most relevant part from the provided list.

    Issue Title: ${issue.title}
    Issue Description: ${issue.description}
    Tags: ${issue.tags.join(', ')}

    Parts:
    ${parts.map(part => `- ${part.name} (${JSON.stringify(part.attributes)})`).join('\n')}

    Suggested Part Name:
    `;
        const response = yield axios_1.default.post('https://api.openai.com/v1/completions', {
            model: 'text-davinci-003',
            prompt: prompt,
            max_tokens: 60,
            temperature: 0.3,
            n: 1,
            stop: ['\n']
        }, {
            headers: {
                'Authorization': `Bearer ${OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });
        const suggestedPartName = response.data.choices[0].text.trim();
        const matchedPart = parts.find(part => part.name.toLowerCase() === suggestedPartName.toLowerCase());
        return matchedPart ? matchedPart.id : null;
    }
    catch (error) {
        console.error('Error in AI relevance suggestion:', error);
        return null;
    }
});
exports.getRelevantPart = getRelevantPart;
