// src/services/partService.ts

import axios from 'axios';
import { Part } from 'C:/Users/shrey/Project_113/code/src/services/types';

export const fetchPartsFromAPI = async (): Promise<Part[]> => {
    try {
        const response = await axios.get('https://api.devrev.ai/parts'); //What must I include here?
        return response.data; 
    } catch (error) {
        console.error('Error fetching parts:', error);
        return []; 
    }
};

export const getRelevantPartByName = (name: string, parts: Part[]): Part | null => {
    return parts.find(part => part.name === name) || null;
};
