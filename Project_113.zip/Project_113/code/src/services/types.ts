// src/services/types.ts

export interface Part {
  id: string;
  name: string;
  attributes: Record<string, any>;
  type: string;
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  tags: string[];
  partId: string;
}

export interface Config {
  partTypes: string[];
  executionFrequency: string; 
}

export interface FunctionError {
  error: string; 
  message?: string; 
}

export enum RuntimeErrorType {
  InvalidRequest = 'InvalidRequest',
  FunctionNameNotProvided = 'FunctionNameNotProvided',
  FunctionNotFound = 'FunctionNotFound',
}

