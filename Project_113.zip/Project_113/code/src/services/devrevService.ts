// src/services/devrevService.ts

import axios from 'axios';
import { Part, Issue } from 'C:/Users/shrey/Project_113/code/src/services/types';

const DEVREV_API_KEY = process.env.DEVREV_API_KEY;
const BASE_URL = 'https://api.devrev.com'; //What must I include here??

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Authorization': `Bearer ${DEVREV_API_KEY}`,
    'Content-Type': 'application/json'
  }
});

export const fetchParts = async (partTypes: string[]): Promise<Part[]> => {
  try {
    const response = await axiosInstance.get('/parts', {
      params: { types: partTypes.join(',') }
    });
    return response.data.parts;
  } catch (error) {
    console.error('Error fetching parts:', error);
    return [];
  }
};

export const fetchIssues = async (): Promise<Issue[]> => {
  try {
    const response = await axiosInstance.get('/issues', {
      params: { status: 'open' }
    });
    return response.data.issues;
  } catch (error) {
    console.error('Error fetching issues:', error);
    return [];
  }
};

export const updateIssuePart = async (issueId: string, partId: string): Promise<void> => {
  try {
    await axiosInstance.patch(`/issues/${issueId}`, { partId });
    console.log(`Issue ${issueId} updated with part ${partId}`);
  } catch (error) {
    console.error(`Error updating issue ${issueId}:`, error);
  }
};
