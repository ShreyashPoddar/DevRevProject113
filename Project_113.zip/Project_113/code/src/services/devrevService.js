"use strict";
// src/services/devrevService.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateIssuePart = exports.fetchIssues = exports.fetchParts = void 0;
const axios_1 = __importDefault(require("axios"));
const DEVREV_API_KEY = process.env.DEVREV_API_KEY;
const BASE_URL = 'https://api.devrev.com'; // Replace with actual DevRev API base URL
const axiosInstance = axios_1.default.create({
    baseURL: BASE_URL,
    headers: {
        'Authorization': `Bearer ${DEVREV_API_KEY}`,
        'Content-Type': 'application/json'
    }
});
const fetchParts = (partTypes) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axiosInstance.get('/parts', {
            params: { types: partTypes.join(',') }
        });
        return response.data.parts;
    }
    catch (error) {
        console.error('Error fetching parts:', error);
        return [];
    }
});
exports.fetchParts = fetchParts;
const fetchIssues = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield axiosInstance.get('/issues', {
            params: { status: 'open' }
        });
        return response.data.issues;
    }
    catch (error) {
        console.error('Error fetching issues:', error);
        return [];
    }
});
exports.fetchIssues = fetchIssues;
const updateIssuePart = (issueId, partId) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield axiosInstance.patch(`/issues/${issueId}`, { partId });
        console.log(`Issue ${issueId} updated with part ${partId}`);
    }
    catch (error) {
        console.error(`Error updating issue ${issueId}:`, error);
    }
});
exports.updateIssuePart = updateIssuePart;
