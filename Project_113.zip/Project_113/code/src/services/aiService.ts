// src/services/aiService.ts

import axios from 'axios';
import { Part } from 'C:/Users/shrey/Project_113/code/src/services/types';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export const getRelevantPart = async (
  issue: { title: string; description: string; tags: string[] },
  parts: Part[]
): Promise<string | null> => {
  try {
    const prompt = `
    Given the following issue details, suggest the most relevant part from the provided list.

    Issue Title: ${issue.title}
    Issue Description: ${issue.description}
    Tags: ${issue.tags.join(', ')}

    Parts:
    ${parts.map(part => `- ${part.name} (${JSON.stringify(part.attributes)})`).join('\n')}

    Suggested Part Name:
    `;

    const response = await axios.post('https://api.openai.com/v1/completions', {
      model: 'text-davinci-003',
      prompt: prompt,
      max_tokens: 60,
      temperature: 0.3,
      n: 1,
      stop: ['\n']
    }, {
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    const suggestedPartName = response.data.choices[0].text.trim();
    const matchedPart = parts.find(part => part.name.toLowerCase() === suggestedPartName.toLowerCase());

    return matchedPart ? matchedPart.id : null;
  } catch (error) {
    console.error('Error in AI relevance suggestion:', error);
    return null;
  }
};
