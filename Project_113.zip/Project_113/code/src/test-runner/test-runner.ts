import { getRelevantPart } from '../services/aiService';
import { Part } from '../services/types';

interface TestRunnerOptions {
  fixturePath: string;
  functionName: string;
}

export const testRunner = async ({ fixturePath, functionName }: TestRunnerOptions): Promise<void> => {
  try {
    
    const issue = {
      title: 'Sample Issue',
      description: 'This is a sample issue description.',
      tags: ['bug', 'frontend']
    };

    const parts: Part[] = [
      {
        id: '1',
        name: 'Part A',
        attributes: {},
        type: 'Type A'
      },
      {
        id: '2',
        name: 'Part B',
        attributes: {},
        type: 'Type B'
      }
    ];

    
    const relevantPartId = await getRelevantPart(issue, parts);

    console.log(`Relevant part ID for the function "${functionName}": ${relevantPartId}`);
  } catch (error) {
    console.error('Error running the test:', error);
  }
};
