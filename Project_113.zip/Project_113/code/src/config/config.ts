// src/config/config.ts

import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { Config } from 'C:/Users/shrey/Project_113/code/src/services/types';

dotenv.config();

const configPath = process.env.SNAPIN_CONFIG_PATH || './config/config.json';

let config: Config;

if (fs.existsSync(configPath)) {
  const configFile = fs.readFileSync(path.resolve(configPath), 'utf-8');
  config = JSON.parse(configFile);
} else {
  // Default configuration
  config = {
    partTypes: ['product'],
    executionFrequency: 'daily'
  };
}

export default config;
