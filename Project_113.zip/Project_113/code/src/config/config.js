"use strict";
// src/config/config.ts
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
dotenv_1.default.config();
const configPath = process.env.SNAPIN_CONFIG_PATH || './config/config.json';
let config;
if (fs_1.default.existsSync(configPath)) {
    const configFile = fs_1.default.readFileSync(path_1.default.resolve(configPath), 'utf-8');
    config = JSON.parse(configFile);
}
else {
    // Default configuration
    config = {
        partTypes: ['product'],
        executionFrequency: 'daily'
    };
}
exports.default = config;
