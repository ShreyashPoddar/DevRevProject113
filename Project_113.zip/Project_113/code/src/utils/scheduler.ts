// src/utils/scheduler.ts

import { processIssues } from '../index'; 
import { Part } from '../services/types';

export const scheduleProcess = async () => {
  
  const issue = {
    title: 'Sample Issue',
    description: 'Description of the issue',
    tags: ['bug', 'urgent'],
  };

  const parts: Part[] = [
    {
      id: '1',
      name: 'Part A',
      attributes: {},
      type: 'Type A', 
    },
    {
      id: '2',
      name: 'Part B',
      attributes: {},
      type: 'Type B', 
    },
  ];

  
  const relevantPartId = await processIssues(issue, parts);
  console.log(`Relevant Part ID from scheduler: ${relevantPartId}`);
};
