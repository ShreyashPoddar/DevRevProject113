"use strict";
// src/utils/scheduler.ts
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startScheduler = void 0;
const node_schedule_1 = __importDefault(require("node-schedule"));
const config_1 = __importDefault(require("../config/config"));
const index_1 = require("../index");
const startScheduler = () => {
    const frequency = config_1.default.executionFrequency;
    let cronExpression;
    switch (frequency) {
        case 'daily':
            cronExpression = '0 0 * * *'; // Every day at midnight
            break;
        case 'weekly':
            cronExpression = '0 0 * * 0'; // Every Sunday at midnight
            break;
        default:
            cronExpression = '*/5 * * * *'; // Every 5 minutes as default
    }
    node_schedule_1.default.scheduleJob(cronExpression, () => {
        console.log('Scheduled job running...');
        (0, index_1.processIssues)();
    });
    console.log(`Scheduler started with frequency: ${frequency}`);
};
exports.startScheduler = startScheduler;
