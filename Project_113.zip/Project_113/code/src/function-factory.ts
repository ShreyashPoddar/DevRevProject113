// src/function-factory.ts


export type FunctionFactoryType = 'functionA' | 'functionB'; 


export const functionA = async (data: any): Promise<void> => {
  console.log('Function A executed with data:', data);
};

export const functionB = async (data: any): Promise<void> => {
  console.log('Function B executed with data:', data);
};


export const callFunction = async (functionName: FunctionFactoryType, data: any): Promise<void> => {
  switch (functionName) {
    case 'functionA':
      return await functionA(data);
    case 'functionB':
      return await functionB(data);
    default:
      throw new Error(`Function ${functionName} is not defined`);
  }
};
